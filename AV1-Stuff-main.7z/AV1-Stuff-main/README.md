# AV1-Stuff
This is a general Git repository to store important/novel information and files about the AV1 standard itself.
